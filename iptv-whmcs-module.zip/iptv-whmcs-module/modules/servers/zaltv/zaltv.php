<?php
if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

function isJson($string)
{
	json_decode($string);
	return (json_last_error() == JSON_ERROR_NONE);
}

function brazuca_MetaData()
{
    return array(
        'DisplayName' => 'ZalTV APP IPTV & Brazuca.tv',
        'APIVersion' => '1.0', // Use API Version 1.1
        'RequiresServer' => false, // Set true if module requires a server to work
    );
}

function brazuca_ConfigOptions()
{
    return array(
        // a text field type allows for single line text input
        'Login do painel ZalTV & Brazuca.tv' => array(
            'Type' => 'text',
            'Size' => '25',
            'Default' => '',
        ),
        // a password field type allows for masked text input
        'Senha do painel ZalTV & Brazuca.tv' => array(
            'Type' => 'password',
            'Size' => '25',
            'Default' => '',
        ),
    );
}

function brazuca_CreateAccount(array $params)
{
    try {
		$serviceID = (int)$params['model']->serviceProperties->get('brazucaServiceID');
		if($serviceID){
			throw new Exception("Já existe um serviço criado, se desejar altere em brazucaServiceID.");
		}
		$dueDate = strtotime($params['model']['nextduedate']." 23:59:00");
		$today = strtotime(date("Y-m-d"));
		$expiry = round(abs($dueDate-$today)/60/60);
		
		$result = file_get_contents("http://18.222.124.50/brazuca.php?cmd=add&login=".$params['configoption1']."&pass=".$params['configoption2']."&contact=".$params['model']['client']['email']."&expiryHours=$expiry");
		if(!$result or !isJson($result)){
			throw new Exception("Não foi possível se conectar a API Brazuca.tv");
		}
		
		$data = json_decode($result, TRUE);
		
		if(isset($data["error"])){
			throw new Exception($data["error"]);
		}
		
		$params['model']->serviceProperties->save(['brazucaServiceID' => $data["id"]]);
		$params['model']->serviceProperties->save(['brazucaToken' => $data["token"]]);
    } catch (Exception $e) {
        // Record the error in WHMCS's module log.
        logModuleCall(
            'brazuca',
            __FUNCTION__,
            $params,
            $e->getMessage(),
            $e->getTraceAsString()
        );

        return $e->getMessage();
    }

    return 'success';
}

function brazuca_Renew(array $params)
{
    try {
		$serviceID = (int)$params['model']->serviceProperties->get('brazucaServiceID');
		if(!$serviceID){
			throw new Exception("Não foi encontrado o ID do serviço Brazuca.tv no seu banco de dados");
		}
		
		$dueDate = strtotime($params['model']['nextduedate']." 23:59:00");
		$today = strtotime(date("Y-m-d"));
		$expiry = round(abs($dueDate-$today)/60/60);
		
		$result = file_get_contents("http://18.222.124.50/brazuca.php?cmd=expiry&login=".$params['configoption1']."&pass=".$params['configoption2']."&id=$serviceID");
		if(!$result or !isJson($result)){
			throw new Exception("Não foi possível se conectar a API Brazuca.tv");
		}
		$data = json_decode($result, TRUE);
		if(isset($data["error"])){
			throw new Exception($data["error"]);
		}
		if(($expiry-5) <= $data["expiry"]){
			throw new Exception("O vencimento é o mesmo, nada foi alterado.");
		} else {
			$expiry = $expiry - $data["expiry"];
		}
		
		$result = file_get_contents("http://18.222.124.50/brazuca.php?cmd=renew&login=".$params['configoption1']."&pass=".$params['configoption2']."&id=$serviceID&expiryHours=$expiry");
		if(!$result or !isJson($result)){
			throw new Exception("Não foi possível se conectar a API ZalTV e Brazuca");
		}
		
		$data = json_decode($result, TRUE);
		
		if(isset($data["error"])){
			throw new Exception($data["error"]);
		}
    } catch (Exception $e) {
        // Record the error in WHMCS's module log.
        logModuleCall(
            'brazuca',
            __FUNCTION__,
            $params,
            $e->getMessage(),
            $e->getTraceAsString()
        );

        return $e->getMessage();
    }

    return 'success';
}

function brazuca_SuspendAccount(array $params)
{
    try {
        // Call the service's suspend function, using the values provided by
        // WHMCS in `$params`.
		$serviceID = (int)$params['model']->serviceProperties->get('brazucaServiceID');
		if(!$serviceID){
			throw new Exception("Não foi encontrado o ID do serviço Brazuca.tv no seu banco de dados");
		}
		
		$result = file_get_contents("http://18.222.124.50/brazuca.php?cmd=disable&login=".$params['configoption1']."&pass=".$params['configoption2']."&id=".$serviceID);
		if(!$result or !isJson($result)){
			throw new Exception("Não foi possível se conectar a API Brazuca.tv");
		}
		
		$data = json_decode($result, TRUE);
		
		if(isset($data["error"])){
			throw new Exception($data["error"]);
		}
    } catch (Exception $e) {
        // Record the error in WHMCS's module log.
        logModuleCall(
            'brazuca',
            __FUNCTION__,
            $params,
            $e->getMessage(),
            $e->getTraceAsString()
        );

        return $e->getMessage();
    }

    return 'success';
}

function brazuca_UnsuspendAccount(array $params)
{
    try {
        // Call the service's unsuspend function, using the values provided by
        // WHMCS in `$params`.
		$serviceID = (int)$params['model']->serviceProperties->get('brazucaServiceID');
		if(!$serviceID){
			throw new Exception("Não foi encontrado o ID do serviço Brazuca.tv no seu banco de dados");
		}
		
		$result = file_get_contents("http://18.222.124.50/brazuca.php?cmd=enable&login=".$params['configoption1']."&pass=".$params['configoption2']."&id=".$serviceID);
		if(!$result or !isJson($result)){
			throw new Exception("Não foi possível se conectar a API Brazuca.tv");
		}
		
		$data = json_decode($result, TRUE);
		
		if(isset($data["error"])){
			throw new Exception($data["error"]);
		}
    } catch (Exception $e) {
        // Record the error in WHMCS's module log.
        logModuleCall(
            'brazuca',
            __FUNCTION__,
            $params,
            $e->getMessage(),
            $e->getTraceAsString()
        );

        return $e->getMessage();
    }

    return 'success';
}

/**
 * Admin services tab additional fields.
 *
 * Define additional rows and fields to be displayed in the admin area service
 * information and management page within the clients profile.
 *
 * Supports an unlimited number of additional field labels and content of any
 * type to output.
 *
 * @param array $params common module parameters
 *
 * @see https://developers.whmcs.com/provisioning-modules/module-parameters/
 * @see provisioningmodule_AdminServicesTabFieldsSave()
 *
 * @return array
 */
function brazuca_AdminServicesTabFields(array $params)
{
    try {
        // Call the service's function, using the values provided by WHMCS in
        // `$params`.
        $response = array();

        // Return an array based on the function's response.
        return array(
            'ID do serviço Brazuca.tv' => (int) $params['model']->serviceProperties->get('brazucaServiceID')
        );
    } catch (Exception $e) {
        // Record the error in WHMCS's module log.
        logModuleCall(
            'brazuca',
            __FUNCTION__,
            $params,
            $e->getMessage(),
            $e->getTraceAsString()
        );

        // In an error condition, simply return no additional fields to display.
    }

    return array();
}

/**
 * Client area output logic handling.
 *
 * This function is used to define module specific client area output. It should
 * return an array consisting of a template file and optional additional
 * template variables to make available to that template.
 *
 * The template file you return can be one of two types:
 *
 * * tabOverviewModuleOutputTemplate - The output of the template provided here
 *   will be displayed as part of the default product/service client area
 *   product overview page.
 *
 * * tabOverviewReplacementTemplate - Alternatively using this option allows you
 *   to entirely take control of the product/service overview page within the
 *   client area.
 *
 * Whichever option you choose, extra template variables are defined in the same
 * way. This demonstrates the use of the full replacement.
 *
 * Please Note: Using tabOverviewReplacementTemplate means you should display
 * the standard information such as pricing and billing details in your custom
 * template or they will not be visible to the end user.
 *
 * @param array $params common module parameters
 *
 * @see https://developers.whmcs.com/provisioning-modules/module-parameters/
 *
 * @return array
 */
function brazuca_ClientArea(array $params)
{
    // Determine the requested action and set service call parameters based on
    // the action.
    $requestedAction = isset($_REQUEST['customAction']) ? $_REQUEST['customAction'] : '';

    if ($requestedAction == 'manage') {
        $serviceAction = 'get_usage';
        $templateFile = 'templates/manage.tpl';
    } else {
        $serviceAction = 'get_stats';
        $templateFile = 'templates/overview.tpl';
    }

    try {
        // Call the service's function based on the request action, using the
        // values provided by WHMCS in `$params`.
        $response = array();

        $brazucaToken = $params['model']->serviceProperties->get('brazucaToken');

        return array(
            'tabOverviewReplacementTemplate' => $templateFile,
            'templateVariables' => array(
                'brazucaToken' => $brazucaToken,
            ),
        );
    } catch (Exception $e) {
        // Record the error in WHMCS's module log.
        logModuleCall(
            'brazuca',
            __FUNCTION__,
            $params,
            $e->getMessage(),
            $e->getTraceAsString()
        );

        // In an error condition, display an error page.
        return array(
            'tabOverviewReplacementTemplate' => 'error.tpl',
            'templateVariables' => array(
                'usefulErrorHelper' => $e->getMessage(),
            ),
        );
    }
}
